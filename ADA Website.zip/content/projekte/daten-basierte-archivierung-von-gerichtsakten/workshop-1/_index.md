+++
template="project.html"
title="Einführung, Problemerfassung und Daten"
extra.sidebar_title="Workshop 1"
weight=0
sort_by="weight"
+++

