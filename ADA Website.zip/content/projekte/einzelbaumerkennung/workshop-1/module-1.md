+++
template="project.html"
title="Module 1"
weight=1
extra.sidebar_title="Module 1"
extra.start_date=""
extra.end_date=""
extra.resources=[
    {title="Slides modul 1", url="ADA4_Modul_1.pdf"}
]
+++
 

 ### Themen

In Modul 1 setzen wir den Rahmen, um Probleme zu erfassen und vorliegende Daten und Arbeitsabläufe zu verstehen. Sie können sich auf folgende Themen freuen:

- Einführung in die Workshop-Serie
- Vorstellung der Problemstellung einzelner Behörden
- Typische Arbeitsabläufe im Kontext fernerkundungsdatengetriebener Waldinventur