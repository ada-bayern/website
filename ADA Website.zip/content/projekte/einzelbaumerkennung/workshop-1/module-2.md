+++
template="project.html"
title="Module 2"
weight=2
extra.sidebar_title="Module 2"
extra.start_date=""
extra.end_date=""
extra.resources=[
    {title="Slides modul 2", url="ADA4_Modul_2.pdf"}
]
+++
 

 ### Themen
In Modul 2 gehen wir auf Infrastrukturbedürfnisse und -möglichkeiten ein und diskutieren dabei insbesondere die Nutzung von Cloud-Anbietern. Sie können sich auf folgende Themen freuen:

- Einführung in Cloud-Computing und Cloud-Anbieter
- Erfahrungen von ADA Bayern im Cloud-Bereich
- Infrastrukturanforderungen von Einzelbaumerkennungsdaten und -systemen- 
- Allgemeine aktuelle Herausforderungen der IT-Infrastruktur
- Mögliche Anwendungen/Produkte