+++
template="project.html"
title="Module 3"
weight=3
extra.sidebar_title="Module 3"
extra.start_date=""
extra.end_date=""
extra.resources=[
    {title="Slides modul 3", url="ADA4_Modul_3.pdf"}
]
+++
 

### Themen
In Modul 3 setzen wir den Rahmen, um Probleme zu erfassen und vorliegende Daten und Arbeitsabläufe zu verstehen. Sie können sich auf folgende Themen freuen:

- Erarbeiten einer sinnvollen Infrastrukturlösung
- Sammlung relevanter Stakeholder und ihrer Bedürfnisse
- Sammlung und Priorisierung von Requirements und Features einer Lösung
- Sammlung von möglichen Risiken
- Vorbereitung der nächsten Schritte im Nachgang des Workshops