+++
template="project.html"
title="Module 3"
weight=3
extra.sidebar_title="Module 3"
extra.start_date=""
extra.end_date=""
resources=[
    { title="Slides", filename="resources/slides1.pdf"},
    { title="Images of the event", filename="resources/slides1.zip"},
]
+++
 

### This is module 3