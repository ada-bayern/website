+++
template="project.html"
title="Module title"
weight=2
extra.sidebar_title="Module 2"
extra.start_date=""
extra.end_date=""
resources=[
    { title="Slides", filename="resources/slides1.pdf"},
    { title="Images of the event", filename="resources/slides1.zip"},
]
+++
 

 ### This is module 2