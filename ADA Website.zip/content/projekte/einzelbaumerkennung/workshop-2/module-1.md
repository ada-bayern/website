+++
template="project.html"
title="Module 1"
weight=1
extra.sidebar_title="Module 1"
extra.start_date=""
extra.end_date=""
resources=[
    { title="Slides", filename="resources/slides1.pdf"},
    { title="Images of the event", filename="resources/slides1.zip"},
]
+++
 

 ### This is module 1